# CANDIDATE_PRINCIPLES

> 当前Phase2状态：374成熟12m、377有效预测；没有通用/条件性优势证据，原15机制仍未测试。以下首段零资料/零执行等陈述为ROUND_001历史快照；本文件末尾是最新追加记录。
本库包含 15 条理论提案，全部源于 master prompt 与经济机制推理（MASTER_PROMPT_DERIVED_UNTESTED），不是 Phase 3 历史遮蔽复盘发现。现有市场实证证据 NONE，已测试市场/行业/regime NONE，已测试观察 0；Confidence UNASSESSED，Statistical Stability NOT TESTED。不能从“尚无反例”推导正确。

这是 Phase 4 的理论研究地图，实际的“从案例提炼规律”被 DATA REQUIRED 阻断。初始 Discovery Origin MASTER_PROMPT_DERIVED_UNTESTED 永久保留；后续仅追加 supporting episode/locked judgment/reveal 和证据状态。新提出的 replay-derived 候选另建 ID 或版本并保留完整出处链，不覆盖原始来源。不得回填虚构证据。

| Candidate | 提案 | 决策类别 | Hypothesis / Experiment | 排序 | Status |
|---|---|---|---|---:|---|
| [CP-001](research/candidate_principles/CP-001.md) | 盈利上修的持续性是否在价格尚未充分反映时有效 | BUY / HOLD 候选 | H-001 / [EXP-001](research/experiments/EXP-001.md) | 3 | PROPOSED_DATA_REQUIRED |
| [CP-002](research/candidate_principles/CP-002.md) | 从账面盈利到可分配自由现金流的转化 | BUY / HOLD 候选 | H-002 / [EXP-002](research/experiments/EXP-002.md) | 4 | PROPOSED_DATA_REQUIRED |
| [CP-003](research/candidate_principles/CP-003.md) | 需求繁荣中的供给扩张是否构成卖出信号 | THESIS-BASED SELL 候选 | H-003 / [EXP-003](research/experiments/EXP-003.md) | 8 | PROPOSED_DATA_REQUIRED |
| [CP-004](research/candidate_principles/CP-004.md) | 好产业在过高隐含增长下是否应 WAIT | NO-TRADE / WAIT 候选 | H-004 / [EXP-004](research/experiments/EXP-004.md) | 7 | PROPOSED_DATA_REQUIRED |
| [CP-005](research/candidate_principles/CP-005.md) | 半导体去库存何时能传递到利润与股价 | BUY / HOLD 候选 | H-005 / [EXP-005](research/experiments/EXP-005.md) | 6 | PROPOSED_DATA_REQUIRED |
| [CP-006](research/candidate_principles/CP-006.md) | 政策执行是否比政策表态提供更多投资信息 | BUY / HOLD / WAIT 候选 | H-006 / [EXP-006](research/experiments/EXP-006.md) | 11 | PROPOSED_DATA_REQUIRED |
| [CP-007](research/candidate_principles/CP-007.md) | 信用恶化是否应优先触发风险减仓或 WAIT | RISK-BASED SELL / NO-TRADE / WAIT 候选 | H-007 / [EXP-007](research/experiments/EXP-007.md) | 1 | PROPOSED_DATA_REQUIRED |
| [CP-008](research/candidate_principles/CP-008.md) | 强制卖出后的反弹是否依赖资产负债表未受损 | BUY 候选；结构受损则 WAIT | H-008 / [EXP-008](research/experiments/EXP-008.md) | 14 | PROPOSED_DATA_REQUIRED |
| [CP-009](research/candidate_principles/CP-009.md) | 资源供给约束是否能转化为生产商股东回报 | BUY / HOLD 候选 | H-009 / [EXP-009](research/experiments/EXP-009.md) | 9 | PROPOSED_DATA_REQUIRED |
| [CP-010](research/candidate_principles/CP-010.md) | 高 ROIC 的再投资是否在稀释后创造股东价值 | BUY / HOLD 候选 | H-010 / [EXP-010](research/experiments/EXP-010.md) | 13 | PROPOSED_DATA_REQUIRED |
| [CP-011](research/candidate_principles/CP-011.md) | 实际利率下降时黄金是否比股票表达更有效 | CROSS-ASSET EXPRESSION 候选 | H-011 / [EXP-011](research/experiments/EXP-011.md) | 5 | PROPOSED_DATA_REQUIRED |
| [CP-012](research/candidate_principles/CP-012.md) | 通胀下行时久期优势是否受期限溢价约束 | CROSS-ASSET BOND / WAIT 候选 | H-012 / [EXP-012](research/experiments/EXP-012.md) | 2 | PROPOSED_DATA_REQUIRED |
| [CP-013](research/candidate_principles/CP-013.md) | 电力负荷增长是否通过监管回报和融资传给股东 | BUY / HOLD / WAIT 候选 | H-013 / [EXP-013](research/experiments/EXP-013.md) | 12 | PROPOSED_DATA_REQUIRED |
| [CP-014](research/candidate_principles/CP-014.md) | 资本分配的真实执行是否优于回购和增持表态 | BUY / HOLD 候选 | H-014 / [EXP-014](research/experiments/EXP-014.md) | 10 | PROPOSED_DATA_REQUIRED |
| [CP-015](research/candidate_principles/CP-015.md) | 技术渗透率增长能否穿透算力成本和竞争转为现金 | BUY / HOLD / WAIT 候选 | H-015 / [EXP-015](research/experiments/EXP-015.md) | 15 | PROPOSED_DATA_REQUIRED |

每条已记录经济机制、同信号成功/失败、missed winners、opposite 定义、混杂、行业/regime 边界、Price-In、PIT 数据需求、最简单实验和 Kill Condition。它们均为待执行的定义；实际案例数全部为 0。

候选提案不是正式投资原则。当前 [INVESTMENT_PHILOSOPHY](INVESTMENT_PHILOSOPHY.md) 不应含任何实证确认规律。升级需多个独立历史案例、反例、成本后可执行性、稳定区间、独立样本与适用边界；无法严格识别因果但未来稳定的预测关系仅可标 PREDICTIVE ASSOCIATION ONLY。[路线图](RESEARCH_ROADMAP.md)说明优先级和停止门槛。

## CYCLE_001_60_REPLAY checkpoint

60个成熟12m标签用于新增固定趋势规则的探索性研究，未检验原15条盈利/估值/信用机制；原15文件保持原哈希。本cycle新增候选0，尚未证明可重复概率优势。

## CYCLE_002_CROSS_DOMAIN_282 checkpoint

282个成熟12m标签用于新增固定趋势规则的探索性研究，未检验原15条盈利/估值/信用机制；原15文件保持原哈希。本cycle新增候选0，尚未证明可重复概率优势。

## CYCLE_003_CALENDAR_EARLY_RECENT checkpoint

374个成熟12m标签用于新增固定趋势规则的探索性研究，未检验原15条盈利/估值/信用机制；原15文件保持原哈希。本cycle新增候选0，尚未证明可重复概率优势。

## CYCLE_004_CASH_SELL_COMPLETE checkpoint

374个成熟12m标签用于新增固定趋势规则的探索性研究，未检验原15条盈利/估值/信用机制；原15文件保持原哈希。本cycle新增候选0，尚未证明可重复概率优势。

## Phase2最终

新增投资原则0；原15条仍未测，confidence与出处不变。RRC-001 D是相对全股票的风险观察，固定50/50提供反证，不是RETURN EDGE或增量风险原则。详见SURVIVING_CANDIDATES；没有A/B-/C晋升。


## Phase3启动

原失败不撤销、原15候选未升级。新增单变量稳定性问题与信用原发布是预注册研究，不是策略救活或投资原则。新结果未揭晓，新增已验证原则0。


## Phase3追加：一个非操作性关联，零新增投资原则

PAC-P3-001 / LEVEL2 / C preliminary / PREDICTIVE_ASSOCIATION_ONLY：美国固定股票ETF集合里，相对自身历史高波动组的12/24m平均收益关系经同季度对照、全部10遗漏和严格非重叠后仍存活。不是更高上涨概率、不是beta匹配alpha、不是已识别经济机制；不得产生买卖规则。完整机制、counterexamples、negative controls、false negatives、产业/市场/年代、持续/套利解释、price-in、失效/下一测试见PHASE3_SURVIVING_PRINCIPLES。主结果后挑选攻击的问题与大范围比较需降级。

本次新增候选关联1/投资原则0；原15条candidate及CURRENT_FRAMEWORK operative candidate列表保持完全不变，没有A/B晋升。


## Phase4 — 没有新增可操作原则

研究对象转向受约束资金。H-P4-001…005是五个机制研究问题，尚非Candidate Investment Principle；动作事实LEVEL2不能升级收益机制。原15候选与PAC-P3-001/C非操作关联原样保留。新增LEVEL3收益机制0、LEVEL4原则0；不因GPIF7条/2年正均值或JPX8条负宽基差而升可信度。研究问题树在HUMAN_DECISION_ARCHITECTURE.md；不是自动BUY规则，不赋未经校准概率。
